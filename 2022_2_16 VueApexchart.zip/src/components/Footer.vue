<template>
  <div class=" bg-primary py-3">
    <div class="container text-center text-white">
      <h1>@2022 Copyright</h1>
    </div>
  </div>
</template>
<script>
export default {
    name: 'home',
  data() {
    return {
      
    }
  },
  methods: {
    
  },
}
</script>